package com.example.chapter71;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter71ApplicationTests {

	@Test
	void contextLoads() {
	}

}
