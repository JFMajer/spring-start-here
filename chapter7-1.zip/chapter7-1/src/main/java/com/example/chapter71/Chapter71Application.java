package com.example.chapter71;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter71Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter71Application.class, args);
	}

}
