package com.example.chapter13springdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter13SpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter13SpringDataApplication.class, args);
	}

}
