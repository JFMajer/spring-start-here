package com.example.chapter13springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter13SpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
